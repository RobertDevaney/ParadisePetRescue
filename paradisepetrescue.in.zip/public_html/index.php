<?php
session_start(); // Start the session to access the session variables
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Paradise Pet Rescue</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Duru+Sans|Actor' rel='stylesheet' type='text/css'>
    <link href="css/bootshape.css" rel="stylesheet">
  </head>
  <body>
    
    <!-- include php script -->
    <?php include 'loginform/fetchusername.php'; ?>

    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><span class="green"></span> Pet Paradise Rescue</a>
        </div>
        <nav role="navigation" class="collapse navbar-collapse navbar-right">
          <ul class="navbar-nav nav">
            <li class="active"><a href="https://paradisepetrescue.in">Home</a></li>
            <li><a href="about/AboutUs.php">About Us</a></li>
            <li><a href="applicationpage/application.php">Adopt</a></li>
            <li><a href="petspage/getpets.php">Pets</a></li>
            <li><a href="donate/donate.php">Donate</a></li>
            <?php if (isset($_SESSION['username'])): ?>
                <li><a href="loginform/logout.php">Logout</a></li>
                <?php if (isset($_SESSION['admin']) && $_SESSION['admin']): ?>
                    <li><a href="admin/admin.php">Admin</a></li>
                <?php endif; ?>
            <?php else: ?>
                <li><a href="loginform/login.html">Login</a></li>
            <?php endif; ?>
            <li><span id="userGreeting">Welcome, <?php echo htmlspecialchars($username); ?></span></li>
          </ul>
        </nav>
      </div>
    </div>
    <div class="jumbotron">
      <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <!-- Carousel items -->
        <ol class="carousel-indicators">
          <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
          <li data-target="#carousel-example-generic" data-slide-to="1"></li>
          <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="item active">
            <img src="img/carousel1.jpg" alt="">
            <div class="carousel-caption"></div>
          </div>
          <div class="item">
            <img src="img/carousel2.jpg" alt="">
            <div class="carousel-caption"></div>
          </div>
          <div class="item">
            <img src="img/carousel3.jpg" alt="">
            <div class="carousel-caption"></div>
          </div>
        </div>
        <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
          <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
          <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
      </div>
    </div>
    <h3 class="text-center">Our Pets</h3>
    <div class="container thumbs">
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <img src="img/pic1.jpg" alt="" class="img-circle">
          <div class="caption">
            <h3 class="text-center">Dogs</h3>
            <p>Energetic, loving and very cuddley, find your future best friend!</p>
            <div class="btn-toolbar text-center">
              <a href="#" role="button" class="btn btn-success">Details</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <img src="img/pic2.jpg" alt="" class="img-circle">
          <div class="caption">
            <h3 class="text-center">Birds</h3>
            <p>Beautiful singers, very cute, playful and the most amazing feathered friend you could ask for.</p>
            <div class="btn-toolbar text-center">
              <a href="#" role="button" class="btn btn-success">Details</a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-sm-6 col-md-4">
        <div class="thumbnail">
          <img src="img/pic3.jpg" alt="" class="img-circle">
          <div class="caption">
            <h3 class="text-center">Cats</h3>
            <p>Feisty yet cuddley, very fluffy and the most comforting purrs in town</p>
            <div class="btn-toolbar text-center">
              <a href="#" role="button" class="btn btn-success">Details</a>
            </div>
          </div>
        </div>
        
      </div>
    </div>
    <div class="container">
      <h3 class="text-center">Welcome to Paradise Pet Rescue</h3>
      <p>Where all animals deserve a 2nd chance. Together we will all strive for that one goal, that no matter the animal, they will get the life they truly deserve.</p>
    </div>
    <div class="footer text-center">
        <p>&copy; 2024 Paradise Pet Rescue All Rights Reserved 
    </div>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootshape.js"></script>
    <script src="js/usergreeting.js"></script>
  </body>
</html>