<?php
session_start(); // Start the session to access the session variables
?>
<!DOCTYPE html>
<html>
<head>
    <title>Paradise Pet Rescue</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Duru+Sans|Actor' rel='stylesheet' type='text/css'>
    <link href="css/bootshape.css" rel="stylesheet">
</head>
<body>
    <!-- include php script -->
    <?php include '../loginform/fetchusername.php'; ?>
    <div class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span the="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Paradise Pet Rescue</a>
            </div>
            <nav role="navigation" class="collapse navbar-collapse navbar-right">
                <ul class="navbar-nav nav">
                    <li class="active"><a href="https://paradisepetrescue.in">Home</a></li>
                    <li><a href="../about/AboutUs.php">About Us</a></li>
                    <li><a href="../applicationpage/application.php">Adopt</a></li>
                    <li><a href="../petspage/getpets.php">Pets</a></li>
                    <li><a href="donate.php">Donate</a></li>
                    <?php if (isset($_SESSION['username'])): ?>
                        <li><a href="../loginform/logout.php">Logout</a></li>
                    <?php if (isset($_SESSION['admin']) && $_SESSION['admin']): ?>
                        <li><a href="../admin/admin.php">Admin</a></li>
                    <?php endif; ?>
                    <?php else: ?>
                        <li><a href="../loginform/login.html">Login</a></li>
                    <?php endif; ?>
                    <li><span id="userGreeting">Welcome, <?php echo htmlspecialchars($username); ?></span></li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="jumbotron">
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="item active">
                    <img src="img/carousel1.jpg" alt="First slide">
                    <div class="carousel-caption"></div>
                </div>
                <div class="item">
                    <img src="img/carousel2.jpg" alt="Second slide">
                    <div class="carousel-caption"></div>
                </div>
                <div class="item">
                    <img src="img/carousel3.jpg" alt="Third slide">
                    <div class="carousel-caption"></div>
                </div>
            </div>
            <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            </a>
            <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            </a>
        </div>
    </div>

    <div class="donation-container">
    <form id="donationForm" onsubmit="return submitDonation()">
        <div class="donation-box">
            <div class="title">Donation Information</div>
            <div class="fields">
                <input type="text" id="firstName" placeholder="First Name" required>
                <input type="text" id="lastName" placeholder="Last Name" required>
                <input type="email" id="email" placeholder="Email" required>
            </div>
            <div class="amount">
                <button type="button" class="button" onclick="selectAmount(10)">$10</button>
                <button type="button" class="button" onclick="selectAmount(20)">$20</button>
                <button type="button" class="button" onclick="selectAmount(50)">$50</button>
                $<input type="number" id="customAmount" class="set-amount" placeholder="" oninput="selectAmount(this.value)" min="1">
            </div>
            
            <button type="submit" class="donate-button">Donate Now</button>
        </div>
    </form>
</div>
    <div class="footer text-center">
        <p>&copy; 2024 Paradise Pet Rescue All Rights Reserved</p>
    </div>
<script>
    // Global variable to store the selected amount
    var selectedAmount = 0;

    // Function to set the selected amount
    function selectAmount(amount) {
        selectedAmount = amount;
    }

    // Function to handle form submission
    function submitDonation() {
        if (selectedAmount > 0) {
            alert('Thank you for your donation of $' + selectedAmount + '!');
            document.getElementById('donationForm').reset(); // Resets the form fields
            selectedAmount = 0; // Reset the selected amount
            setTimeout(function() {
                window.location.href = 'donate.html'; // Redirects to the donation page after 2 seconds
            }, 2000);
            return false; // Prevent form submission
        } else {
            alert('Please select a donation amount.');
            return false; // Prevent form submission
        }
    }
</script>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootshape.js"></script>
    
</body>
</html>
