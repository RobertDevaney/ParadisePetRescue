<?php
include '../database.php';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["petPhoto"])) {
    // Sanitize and assign the pet name
    $petName = filter_var($_POST["petName"], FILTER_SANITIZE_STRING);

    // Proceed with file upload
    $target_dir = "../photos/"; // Adjust the path as needed
    $base_filename = basename($_FILES["petPhoto"]["name"]);
    $safe_filename = preg_replace("/[^a-zA-Z0-9.]/", "_", $base_filename);
    $target_file = $target_dir . $safe_filename;

    // Validate and move the uploaded file
    if (move_uploaded_file($_FILES["petPhoto"]["tmp_name"], $target_file)) {
        // Prepare the SQL statement to insert the pet details into the Pets table
        $stmt = $conn->prepare("INSERT INTO Pets (Name, image_path) VALUES (?, ?)");
        $stmt->bind_param("ss", $petName, $target_file);
        
        // Execute the prepared statement
        if ($stmt->execute()) {
            echo "New pet created successfully. Image uploaded.";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
} else {
    echo "Invalid request";
}

// Close the database connection
$conn->close();
?>
