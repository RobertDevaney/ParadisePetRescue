<?php
session_start();
if (!isset($_SESSION['admin']) || !$_SESSION['admin']) {
    header('Location: ../loginform/login.html'); // Redirect non-admins
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload Pet Image</title>
</head>
<body>
    <h2>Upload Pet Image</h2>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <label for="petName">Pet Name:</label>
        <input type="text" name="petName" id="petName" required>
        <br><br>
        <label for="petPhoto">Select image to upload:</label>
        <input type="file" name="petPhoto" id="petPhoto" required>
        <br><br>
        <input type="submit" value="Upload Image" name="submit">
    </form>
</body>
</html>
